import React,{Component} from 'react'
import {View,Text} from 'react-native'

export default class Mine extends Component{
    render(){
        return <View>
            <Text>Mine...</Text>
        </View>
    }
}