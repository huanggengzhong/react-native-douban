# React Navigation
    https://reactnavigation.org/

## 分类
    createStackNavigator 顶部导航
        https://reactnavigation.org/docs/zh-Hans/navigating.html

    createBottomTabNavigator 底部Tab
        https://reactnavigation.org/docs/zh-Hans/tab-based-navigation.html

    createDrawerNavigator 抽屉效果
        https://reactnavigation.org/docs/zh-Hans/drawer-based-navigation.html

## API地址
    https://reactnavigation.org/docs/zh-Hans/api-reference.html

# 轮播图
    包名:react-native-looped-carousel

    地址:https://github.com/phil-r/react-native-looped-carousel

# 上拉加载 & 下拉刷新
    包名：react-native-refresh-list-view

    地址:https://github.com/huanxsd/react-native-refresh-list-view
        
